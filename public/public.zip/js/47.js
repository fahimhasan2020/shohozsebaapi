(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[47],{

/***/ "./resources/js/Pages/Users/Nursing/Nurs":
/*!***********************************************!*\
  !*** ./resources/js/Pages/Users/Nursing/Nurs ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module build failed: Error: ENOENT: no such file or directory, open 'D:\\Shohoz Seba\\Api\\resources\\js\\Pages\\Users\\Nursing\\Nurs'");

/***/ })

}]);