(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[50],{

/***/ "./public/admin/assets/images/icons/assistant.svg":
/*!********************************************************!*\
  !*** ./public/admin/assets/images/icons/assistant.svg ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/assistant.svg?e89591e44ab6760c13f0ede9220082b4";

/***/ })

}]);