(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[42],{

/***/ "./public/admin/assets/images/empty.png":
/*!**********************************************!*\
  !*** ./public/admin/assets/images/empty.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/empty.png?9b37315e3cfb40183c0203603499ea48";

/***/ }),

/***/ "./public/admin/assets/images/icons/assistant.svg":
/*!********************************************************!*\
  !*** ./public/admin/assets/images/icons/assistant.svg ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/assistant.svg?e89591e44ab6760c13f0ede9220082b4";

/***/ })

}]);